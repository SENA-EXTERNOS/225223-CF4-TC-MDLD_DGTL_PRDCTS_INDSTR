function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6eyUeapvUeN":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

